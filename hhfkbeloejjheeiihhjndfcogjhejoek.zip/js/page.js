
const downloadButton = document.getElementById("downloadButton");

downloadButton.onclick = function(){
    downloadButton.disabled = true;
    chrome.devtools.inspectedWindow.getResources(
        (resources) => {
            var c = 0;
            var zip = new JSZip();
            const total = resources.length;
            for (const resource of resources) {                

                resource.getContent((content, encoding)=> {
                    zip.file(resource.url, content, {base64: encoding == 'base64'});
                    c = c + 1;
                    if (c == total){
                        zip.generateAsync({type:"blob"})
                        .then(function(zipContent) {                    
                            saveAs(zipContent, "sources.zip");
                        });
                        
                        downloadButton.disabled = false;
                    }
                });
            }
        }
    )
}